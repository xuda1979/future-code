Adaptive HACT - TSE source package

Primary article: journal.tex
Technical supplement: tse_supplement.tex
Cover letter: tse_cover_letter.tex (for editors only)

Build each entry point with pdflatex three times in a clean directory.
All referenced local inputs and figures are included at one folder level.
The unmodified IEEEtran class is bundled; other packages are standard TeX Live packages.
JSS variants and the historical full manuscript are outside this package.
SOURCE_MANIFEST.json binds every other file by size and SHA-256.
The source package contains no author approval or submission attestations.
Final submission remains paused for author review.
